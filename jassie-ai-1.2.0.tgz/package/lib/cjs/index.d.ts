import { JassieAI } from './client.js';
export { JassieAI } from './client.js';
export default JassieAI;
export type { JassieAIOptions, Platform, Message, TextModel, CodeModel, ImageModel, VideoModel, MusicModel, Usage, JassieChunk, Speaker, ConversationMessage, ConversationStreamParams, TextGenerateParams, TextStreamParams, CodeGenerateParams, CodeStreamParams, ImageGenerateParams, Reference, VideoGenerateParams, MusicGenerateParams, TextResponse, ImageTaskResponse, VideoTaskResponse, MusicTaskResponse, PollOptions, ImageStreamStatus, ImageStreamPreview, ImageStreamCompleted, ImageStreamFailed, ImageStreamEvent, } from './types.js';
export { JassieError, JassieAPIError, JassieAuthenticationError, JassieRateLimitError, JassieTimeoutError, JassieConnectionError, } from './errors.js';
export { JassieStream } from './streaming/stream.js';
export { ImageStream } from './streaming/image-stream.js';
//# sourceMappingURL=index.d.ts.map