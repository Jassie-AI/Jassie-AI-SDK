export declare class JassieError extends Error {
    constructor(message: string);
}
export declare class JassieAPIError extends JassieError {
    readonly status: number;
    constructor(status: number, message: string);
    static fromResponse(status: number, body: any): JassieAPIError;
}
export declare class JassieAuthenticationError extends JassieAPIError {
    constructor(message?: string);
}
export declare class JassieRateLimitError extends JassieAPIError {
    readonly retryAfter?: number;
    constructor(message?: string, retryAfter?: number);
}
export declare class JassieTimeoutError extends JassieError {
    constructor(message?: string);
}
export declare class JassieConnectionError extends JassieError {
    constructor(message?: string);
}
//# sourceMappingURL=errors.d.ts.map