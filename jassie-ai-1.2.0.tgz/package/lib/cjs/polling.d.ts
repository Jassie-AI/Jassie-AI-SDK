export interface PollConfig<T> {
    fetcher: () => Promise<T>;
    isComplete: (result: T) => boolean;
    interval?: number;
    timeout?: number;
    onPoll?: (result: T) => void;
}
export declare function poll<T>(config: PollConfig<T>): Promise<T>;
//# sourceMappingURL=polling.d.ts.map