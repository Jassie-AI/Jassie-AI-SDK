export interface ClientInterface {
    _request<T>(method: string, path: string, body?: any): Promise<T>;
    _requestRaw(method: string, path: string, body?: any): Promise<Response>;
    _requestMultipart<T>(path: string, formData: FormData): Promise<T>;
    _requestMultipartRaw(path: string, formData: FormData): Promise<Response>;
    _stream(method: string, path: string, body: any): import('./streaming/stream.js').JassieStream;
    _imageStream(path: string, body: any): import('./streaming/image-stream.js').ImageStream;
}
export type Platform = 'node' | 'web' | 'react-native';
export interface JassieAIOptions {
    apiKey: string;
    baseURL?: string;
    timeout?: number;
    maxRetries?: number;
    platform?: Platform;
}
export interface Message {
    role: 'system' | 'user' | 'assistant';
    content: string;
    image?: string | string[];
    images?: string[];
    video?: string | string[];
    audio?: string;
}
export type TextModel = 'jassie-pulse' | 'jassie-bolt';
export type CodeModel = 'jassie-code';
export type ImageModel = 'jassie-pixel' | 'jassie-pixel-x';
export type VideoModel = 'jassie-vibe' | 'jassie-motion' | 'jassie-cinema';
export type MusicModel = 'jassie-beat';
export interface Usage {
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens: number;
}
export interface JassieChunk {
    type: 'queued' | 'text' | 'thinking' | 'web' | 'web_search' | 'error' | 'audio' | 'start' | 'done' | 'queue_position';
    content?: string;
    done?: boolean;
    data?: string;
    fallback?: boolean;
    index?: number;
    chunks?: number;
    position?: number;
    request_id?: string;
    duration_seconds?: number;
    query?: string;
    usage?: Usage;
}
export type Speaker = 'ethan' | 'chelsie' | 'aiden';
export interface TextGenerateParams {
    model: TextModel;
    messages: Message[];
    stream?: false;
    maxTokens?: number;
    temperature?: number;
    web?: 'auto' | 'always' | null;
    modalities?: ('text' | 'audio')[];
    speaker?: Speaker;
}
export interface TextStreamParams {
    model: TextModel;
    messages: Message[];
    stream?: true;
    maxTokens?: number;
    temperature?: number;
    web?: 'auto' | 'always' | null;
    modalities?: ('text' | 'audio')[];
    speaker?: Speaker;
}
export interface ConversationMessage {
    role: 'system' | 'user' | 'assistant';
    content?: string;
    images?: string[];
    video?: string[];
    audio?: string;
}
export interface ConversationStreamParams {
    messages: ConversationMessage[];
    stream?: true;
    max_tokens?: number;
    maxTokens?: number;
    temperature?: number;
    modalities?: ('text' | 'audio')[];
    speaker?: Speaker;
    web?: 'auto' | 'always' | null;
}
export interface CodeGenerateParams {
    model: CodeModel;
    messages: Message[];
    stream?: false;
    maxTokens?: number;
    temperature?: number;
    web?: 'auto' | 'always' | null;
}
export interface CodeStreamParams {
    model: CodeModel;
    messages: Message[];
    stream?: true;
    maxTokens?: number;
    temperature?: number;
    web?: 'auto' | 'always' | null;
}
export interface ImageGenerateParams {
    model: ImageModel;
    prompt: string;
    image?: string | string[];
    aspectRatio?: string;
    width?: number;
    height?: number;
    showcase?: boolean;
}
export interface Reference {
    type: 'image' | 'video' | 'audio';
    url: string;
}
export interface VideoGenerateParams {
    model: VideoModel;
    prompt: string;
    duration?: number;
    references?: Reference[];
    firstFrame?: string;
    lastFrame?: string;
    aspectRatio?: string;
}
export interface MusicGenerateParams {
    model: MusicModel;
    tags: string;
    lyrics?: string;
    seed?: number;
    duration: number;
}
export interface TextResponse {
    type: 'text' | 'error';
    content: string;
    index?: number;
    request_id?: string;
    chunks?: number;
    duration_seconds?: number;
    web_search?: {
        query: string;
    };
}
export interface ImageTaskResponse {
    type?: 'status' | 'completed' | 'failed';
    model: string;
    taskId: string;
    status: 'pending' | 'preview_ready' | 'succeeded' | 'failed' | 'cancelled';
    imageUrl: string | null;
    expiresOn: string | null;
}
export interface VideoTaskResponse {
    model: string;
    taskId: string;
    status: 'pending' | 'running' | 'succeeded' | 'failed' | 'cancelled';
    videoUrl: string | null;
    expiresOn: string | null;
}
export interface MusicTaskResponse {
    model: string;
    taskId: string;
    status: 'pending' | 'processing' | 'completed' | 'failed' | 'cancelled';
    musicUrl: string | null;
    expiresOn: string | null;
}
export interface ImageStreamStatus {
    type: 'status';
    model: string;
    taskId: string;
    status: string;
}
export interface ImageStreamPreview {
    type: 'preview';
    model: string;
    taskId: string;
    imageUrl: string;
}
export interface ImageStreamCompleted {
    type: 'completed';
    model: string;
    taskId: string;
    status: string;
    imageUrl: string | null;
    expiresOn: string | null;
}
export interface ImageStreamFailed {
    type: 'failed';
    model: string;
    taskId: string;
    status: string;
    imageUrl: null;
    expiresOn: null;
    error: string;
}
export type ImageStreamEvent = ImageStreamStatus | ImageStreamPreview | ImageStreamCompleted | ImageStreamFailed;
export interface PollOptions {
    interval?: number;
    timeout?: number;
    onPoll?: (response: any) => void;
    showcase?: boolean;
}
export interface StreamTransportOptions {
    url: string;
    method: string;
    headers: Record<string, string>;
    body: string;
    signal?: AbortSignal;
}
//# sourceMappingURL=types.d.ts.map