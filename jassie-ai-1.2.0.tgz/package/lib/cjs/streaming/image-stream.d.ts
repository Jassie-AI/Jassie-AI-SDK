import type { ImageStreamEvent } from '../types.js';
export declare class ImageStream implements AsyncIterable<ImageStreamEvent> {
    private queue;
    private resolve;
    private abortController;
    private ended;
    constructor(abortController?: AbortController);
    get signal(): AbortSignal;
    _push(event: ImageStreamEvent): void;
    _end(): void;
    _error(err: Error): void;
    abort(): void;
    /** Iterate progress events via callback. Resolves when the stream ends. */
    eachEvent(cb: (event: ImageStreamEvent) => void): Promise<void>;
    /** Collect and return the final completed event (or null if not found). */
    finalResult(): Promise<ImageStreamEvent | null>;
    private next;
    [Symbol.asyncIterator](): AsyncIterator<ImageStreamEvent>;
    ['@@asyncIterator'](): AsyncIterator<ImageStreamEvent>;
}
//# sourceMappingURL=image-stream.d.ts.map