import type { JassieChunk } from '../types.js';
export declare class JassieStream implements AsyncIterable<JassieChunk> {
    private queue;
    private resolve;
    private abortController;
    private ended;
    constructor(abortController?: AbortController);
    get signal(): AbortSignal;
    /** Called by transports to push a chunk */
    _push(chunk: JassieChunk): void;
    /** Called by transports when the stream ends */
    _end(): void;
    /** Called by transports on error */
    _error(err: Error): void;
    /** Cancel the stream */
    abort(): void;
    /** Iterate text chunks via callback. Resolves when the stream ends. */
    eachText(cb: (text: string) => void): Promise<void>;
    /** Collect all text chunks into a single string */
    finalText(): Promise<string>;
    private next;
    [Symbol.asyncIterator](): AsyncIterator<JassieChunk>;
    ['@@asyncIterator'](): AsyncIterator<JassieChunk>;
}
//# sourceMappingURL=stream.d.ts.map