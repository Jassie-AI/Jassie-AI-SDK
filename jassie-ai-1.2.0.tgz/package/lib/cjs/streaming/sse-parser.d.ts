import type { JassieChunk } from '../types.js';
export declare class SSEParser {
    private buffer;
    feed(text: string): JassieChunk[];
    flush(): JassieChunk[];
    private parseEvent;
}
//# sourceMappingURL=sse-parser.d.ts.map