import type { Platform } from '../types.js';
export declare function detectPlatform(): Platform;
//# sourceMappingURL=platform.d.ts.map