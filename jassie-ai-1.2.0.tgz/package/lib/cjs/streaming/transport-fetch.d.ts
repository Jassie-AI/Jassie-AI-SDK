import type { StreamTransportOptions } from '../types.js';
import { JassieStream } from './stream.js';
export declare function startFetchTransport(options: StreamTransportOptions, stream: JassieStream): void;
//# sourceMappingURL=transport-fetch.d.ts.map