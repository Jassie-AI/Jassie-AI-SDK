import type { StreamTransportOptions } from '../types.js';
import { JassieStream } from './stream.js';
export declare function startXHRTransport(options: StreamTransportOptions, stream: JassieStream): void;
//# sourceMappingURL=transport-xhr.d.ts.map