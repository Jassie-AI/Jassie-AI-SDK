import type { ClientInterface, TextGenerateParams, TextStreamParams, TextResponse, ConversationStreamParams } from '../types.js';
import type { JassieStream } from '../streaming/stream.js';
export declare class Text {
    private client;
    constructor(client: ClientInterface);
    /** Generate a text response. Set stream: true for real-time streaming. */
    generate(params: TextStreamParams): JassieStream;
    generate(params: TextGenerateParams): Promise<TextResponse>;
    /**
     * Stream a conversation via /v1/conversation.
     * Supports text, images, video, and audio input/output.
     * This endpoint handles multimodal messages natively.
     */
    conversation(params: ConversationStreamParams): JassieStream;
}
//# sourceMappingURL=text.d.ts.map