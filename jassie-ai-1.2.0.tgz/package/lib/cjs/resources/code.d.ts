import type { ClientInterface, CodeGenerateParams, CodeStreamParams, TextResponse } from '../types.js';
import type { JassieStream } from '../streaming/stream.js';
export declare class Code {
    private client;
    constructor(client: ClientInterface);
    /** Generate code. Set stream: true for real-time streaming. */
    generate(params: CodeStreamParams): JassieStream;
    generate(params: CodeGenerateParams): Promise<TextResponse>;
}
//# sourceMappingURL=code.d.ts.map