import type { ClientInterface, MusicGenerateParams, MusicTaskResponse, PollOptions } from '../types.js';
export declare class Music {
    private client;
    constructor(client: ClientInterface);
    /** Start music generation. Returns immediately with a taskId. */
    generate(params: MusicGenerateParams): Promise<MusicTaskResponse>;
    /**
     * Check music task status.
     *
     * - `status(taskId)` → single status check (one HTTP call).
     * - `status(taskId, { onPoll, interval, timeout })` → polls until the task
     *   reaches a terminal state (`completed` or `failed`), invoking `onPoll`
     *   on every poll iteration.
     */
    status(taskId: string, options?: PollOptions): Promise<MusicTaskResponse>;
    /** Cancel a music generation task. */
    cancel(taskId: string): Promise<MusicTaskResponse>;
}
//# sourceMappingURL=music.d.ts.map