import type { ClientInterface, ImageGenerateParams, ImageTaskResponse, PollOptions } from '../types.js';
import type { ImageStream } from '../streaming/image-stream.js';
export declare class Image {
    private client;
    constructor(client: ClientInterface);
    /** Generate an image synchronously (v1). Blocks until the image is ready. */
    generate(params: ImageGenerateParams): Promise<ImageTaskResponse>;
    /** Start async image generation (v2). Returns immediately with a taskId. */
    generateAsync(params: ImageGenerateParams): Promise<ImageTaskResponse>;
    /**
     * Check image task status.
     *
     * - `status(taskId)` → single JSON status check.
     * - `status(taskId, { onPoll, interval, timeout })` → polls until
     *   the task reaches a terminal state.
     */
    status(taskId: string, options?: PollOptions): Promise<ImageTaskResponse>;
    /**
     * Stream image generation status via Server-Sent Events (SSE).
     * Returns an ImageStream (async iterable) that yields status,
     * preview, and completion events in real time.
     *
     * ```ts
     * const stream = client.image.statusStream(taskId);
     * for await (const event of stream) { ... }
     * ```
     */
    statusStream(taskId: string): ImageStream;
    /** Cancel an image generation task. */
    cancel(taskId: string): Promise<ImageTaskResponse>;
}
//# sourceMappingURL=image.d.ts.map