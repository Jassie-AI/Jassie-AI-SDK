import type { ClientInterface, VideoGenerateParams, VideoTaskResponse, PollOptions } from '../types.js';
export declare class Video {
    private client;
    constructor(client: ClientInterface);
    /** Start video generation. Returns immediately with a taskId. */
    generate(params: VideoGenerateParams): Promise<VideoTaskResponse>;
    /**
     * Check video task status.
     *
     * - `status(taskId)` → single status check (one HTTP call).
     * - `status(taskId, { onPoll, interval, timeout })` → polls until the task
     *   reaches a terminal state (`succeeded` or `failed`), invoking `onPoll`
     *   on every poll iteration.
     */
    status(taskId: string, options?: PollOptions): Promise<VideoTaskResponse>;
    /** Cancel a video generation task. */
    cancel(taskId: string): Promise<VideoTaskResponse>;
}
//# sourceMappingURL=video.d.ts.map