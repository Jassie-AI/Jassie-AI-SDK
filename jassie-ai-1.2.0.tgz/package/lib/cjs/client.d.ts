import type { JassieAIOptions } from './types.js';
import { JassieStream } from './streaming/stream.js';
import { ImageStream } from './streaming/image-stream.js';
import { Text } from './resources/text.js';
import { Code } from './resources/code.js';
import { Image } from './resources/image.js';
import { Video } from './resources/video.js';
import { Music } from './resources/music.js';
export declare class JassieAI {
    private apiKey;
    private baseURL;
    private timeout;
    private maxRetries;
    private platform;
    readonly text: Text;
    readonly code: Code;
    readonly image: Image;
    readonly video: Video;
    readonly music: Music;
    constructor(options: JassieAIOptions);
    private buildHeaders;
    /** JSON request with retry logic */
    _request<T>(method: string, path: string, body?: any): Promise<T>;
    /** Raw request with retry logic — returns the raw Response (for binary data like audio). */
    _requestRaw(method: string, path: string, body?: any): Promise<Response>;
    /** Multipart form-data request with retry logic — returns parsed JSON */
    _requestMultipart<T>(path: string, formData: FormData): Promise<T>;
    /** Multipart form-data request with retry logic — returns raw Response (for binary data) */
    _requestMultipartRaw(path: string, formData: FormData): Promise<Response>;
    /** Start a streaming request, returns JassieStream async iterable */
    _stream(method: string, path: string, body: any): JassieStream;
    /** Start a streaming image request, returns ImageStream async iterable */
    _imageStream(path: string, body: any): ImageStream;
    private backoff;
}
//# sourceMappingURL=client.d.ts.map